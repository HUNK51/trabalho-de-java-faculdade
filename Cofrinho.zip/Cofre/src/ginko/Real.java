package ginko;//banco

public class Real extends Moeda {
	
	public Real (double Valor) {
		this.Valor = Valor;
	}

	@Override
	public void info() {
		
		System.out.println("Real - " + Valor);
	}

	@Override
	public double converter() {//valor da moeda
		return 
		this.Valor;
		
	}

	
}




