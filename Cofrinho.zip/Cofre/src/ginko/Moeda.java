package ginko;//banco

import java.util.Objects;

public abstract class Moeda { //classe mae
	 double Valor;
	
	public abstract void info();
	//no meu hash code meu codigo funcionou normalmente colocando-o apenas na classe mae, cheguei a tentar colocar nas 
	//classes filhas mas source nn mostrava a opção dai decidi testar dessa forma pra ver se ia e funcionou
	//o motivo de escrever isso é se caso as versoes forem diferentes desde ja grato a atenção gratidão.
	
	
	


	public abstract double converter();
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(Valor);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}





	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Moeda other = (Moeda) obj;
		if (Double.doubleToLongBits(Valor) != Double.doubleToLongBits(other.Valor))
			return false;
		return true;
	}	
	

	}

