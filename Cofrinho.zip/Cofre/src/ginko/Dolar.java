package ginko;//banco

public class Dolar extends Moeda {
	public Dolar (double Valor) {
		this.Valor = Valor;
	}

	@Override
	public void info() {
		System.out.println("dolar - " + Valor);

	}

	
	
	@Override
	public double converter() {//valor da moeda
	return	
	 this.Valor * 3.8;

		
	}


		
	}
	
	


