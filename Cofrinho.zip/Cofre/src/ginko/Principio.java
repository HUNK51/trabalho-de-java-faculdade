package ginko; //banco em japones coloquei assim pra da uma diferenciada

import java.util.Scanner;

public class Principio {



	public static void main(String[] args) {//menu inicial
		Scanner teclado = new Scanner(System.in);
		int opcao;
		
		Cofre cofre = new Cofre();
		
		System.out.println("MENU");
		System.out.println("1-Adicionar Moeda");
		System.out.println("2-Remover Moeda");
		System.out.println("3-Listagem de Moedas");
		System.out.println("4-Total Convertido");
		System.out.println("0-Encerrar");
		
		opcao=teclado.nextInt();
		double tipoMoeda;
		Moeda dindin;
		while(opcao!=0) 
		{
//_____________________________________________________________________________
			switch(opcao) {
			case 1:
				//adicionar
				tipoMoeda=0;                                        //implementação do menu adicionar
			
				while(tipoMoeda>3||tipoMoeda<=0) {
					System.out.println("1-Adicionar Real");
					System.out.println("2-Adicionar Dolar");
					System.out.println("3-Adicionar Euro");
					tipoMoeda = teclado.nextInt();
				}
				
			       dindin = null;
				if(tipoMoeda==1) {
					System.out.println("De quantos Reais voce gostaria ?");
					double Valor = teclado.nextDouble();

					dindin = new Real (Valor);
					
					
				}
				
				
				if(tipoMoeda==2) {
					System.out.println("De quantos Dolares voce gostaria ?");
					 double Valor = teclado.nextDouble();

					dindin = new Dolar(Valor);

				}
				
				
				 if(tipoMoeda==3) {
					System.out.println("De quantos Euros voce gostaria ?");

					 double Valor = teclado.nextDouble();

					dindin = new Euro(Valor);

				}
				
				cofre.adicionar(dindin);
				
				
//______________________________________________________________________


				break;
			case 2:
				//remover                                        //implementação do menu remover
				tipoMoeda=0;
				

				
				while(tipoMoeda>3||tipoMoeda<=0) {
					System.out.println("1-Remover Real");
					System.out.println("2-Remover Dolar");
					System.out.println("3-Remover Euro");
					tipoMoeda = teclado.nextInt();
				}
				
				  dindin = null;

				if(tipoMoeda==1) {
					System.out.println("Quantos Reais voce gostaria de remover ?");
					 double Valor = teclado.nextDouble();

					dindin = new Real(Valor);

				}
				
				
				if(tipoMoeda==2) {
					System.out.println("Quantos Dolares voce gostaria de remover ?");
					 double Valor = teclado.nextDouble();
					 
					dindin = new Dolar(Valor);

				}
				
				
				if(tipoMoeda==3){
					System.out.println("Quantos Euros voce gostaria de remover ?");
					 double Valor = teclado.nextDouble();

					dindin = new Euro(Valor);

				}
				cofre.remove(dindin);
				
//______________________________________________________________________________________________

				break;
			case 3:
				//listagem                        //mostrar listar
			cofre.listar();
			
				break;
			case 4:
			//totalconvertido                           //implementação do menu total convertido
			double valorConvertido = cofre.valorConvertido();
			System.out.println("O total convertido para reais foi de:" + valorConvertido);
			
				break;
			default:
				System.out.println("Opcao invalida");
			}
			System.out.println("MENU");
			System.out.println("1-Adicionar Moeda");
			System.out.println("2-Remover Moeda");
			System.out.println("3-Listagem de Moedas");
			System.out.println("4-Total Convertido");
			System.out.println("0-Encerrar");
			opcao=teclado.nextInt();

		}
		
	}

}
