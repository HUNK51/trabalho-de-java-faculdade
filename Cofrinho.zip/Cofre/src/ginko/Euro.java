package ginko;//banco

public class Euro extends Moeda {
	public Euro (double Valor) {
		this.Valor = Valor;
	}

	@Override
	public void info() {
		System.out.println("Euro - " + Valor);

	}

	@Override
	public double converter() {//valor da moeda
		return	
		this.Valor * 5.1;
		
	}

		

	
}



