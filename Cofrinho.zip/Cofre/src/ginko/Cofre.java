package ginko;//banco

import java.util.ArrayList;

public class Cofre {
		private ArrayList<Moeda> listaMoeda= new ArrayList<Moeda>();
		
	
		public  void adicionar(Moeda moedam) {//lista de moedas
			
			 this.listaMoeda.add( moedam);

		}
	
		public void remove(Moeda moedam) {//remove moedas
	
			this.listaMoeda.remove(moedam);
		}
		public void listar() {// listar moedas
			if (this.listaMoeda.isEmpty()) {
				System.out.println("!!!!O cofrinho esta vazio!!!!");
				return;
			}
		
			for(Moeda moedam  : listaMoeda) {
				moedam.info();

			}
		
		}
		public double valorConvertido() {//converter moeda
			if (this.listaMoeda.isEmpty()) {
				return 0;	
				}
				double valorJunto = 0;
				for (Moeda moedam : this.listaMoeda) {
					valorJunto = valorJunto + moedam.converter();
				}
				return valorJunto;
		}
		
		
}
		
			
	
	


